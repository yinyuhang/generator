package com.shark.generator;

public enum FileType {
    REPOSITORY, CONTROLLER, POJO, HTML,
}
