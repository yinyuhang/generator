package com.shark.generator;

public enum  ExpressionType {
    NOT_NULL, NOT_EMPTY
}
